import { integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import type { AutoSettings, EditorSettings, StoryScene } from "@/lib/types";
import { DEFAULT_EDITOR_SETTINGS } from "@/lib/types";

export const studioOwner = pgTable("studio_owner", {
  id: integer("id").primaryKey().default(1),
  pinHash: text("pin_hash").notNull(),
  failedAttempts: integer("failed_attempts").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const studioSessions = pgTable("studio_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const projects = pgTable("studio_projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  idea: text("idea").notNull(),
  category: text("category").notNull().default("Adventure"),
  ageGroup: text("age_group").notNull().default("3–5 years"),
  duration: integer("duration").notNull().default(30),
  style: text("style").notNull().default("Storybook"),
  character: text("character").notNull().default("fox"),
  scenes: jsonb("scenes").$type<StoryScene[]>().notNull().default([]),
  editSettings: jsonb("edit_settings").$type<EditorSettings>().notNull().default(DEFAULT_EDITOR_SETTINGS),
  status: text("status").notNull().default("draft"),
  thumbnail: text("thumbnail"),
  youtubeTitle: text("youtube_title").notNull().default(""),
  description: text("description").notNull().default(""),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  privacy: text("privacy").notNull().default("private"),
  youtubeVideoId: text("youtube_video_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const studioIntegrations = pgTable("studio_integrations", {
  id: integer("id").primaryKey().default(1),
  youtubeRefreshToken: text("youtube_refresh_token"),
  youtubeChannelTitle: text("youtube_channel_title"),
  youtubeChannelId: text("youtube_channel_id"),
  youtubeChannelAvatar: text("youtube_channel_avatar"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const studioSettings = pgTable("studio_settings", {
  id: integer("id").primaryKey().default(1),
  secrets: jsonb("secrets").$type<Record<string, string>>().notNull().default({}),
  auto: jsonb("auto").$type<AutoSettings>().notNull().default({ enabled: false, autoPost: false, visibility: "private", lastRunDate: null }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
