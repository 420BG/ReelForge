# Littleloop Studio

A private, single-owner studio for original animated kids' YouTube Shorts. Go from an idea to an editable storyboard, animate it, add real voice audio, export a vertical WebM, and optionally upload to your own YouTube channel.

## What works without any AI key

- Set up a private owner PIN/passphrase. Projects and sessions live in PostgreSQL; PINs are hashed.
- Make stories with eight themes and the built-in story writer.
- Animate a drawn cartoon character in every scene. Pick **bounce, walk, dance, float, or wave**, facial expressions, props, scene colors, camera moves, and entrances.
- Add your own image as a moving/panning background behind the cartoon character, or use the built-in animated world. A photo is never the *only* animated layer unless you turn the character layer off.
- Edit a multi-track timeline: reorder and duplicate clips, set 2–20-second scene durations (up to 60 seconds total), scrub playback, undo/redo, choose caption designs, and mix an original background-music preset.
- **Record your own character voices through your microphone or import existing voice clips.** Saved voice files play during preview and are mixed into the exported video.
- Export a real 540 × 960 WebM with character movement, transitions, captions, soundtrack, and any saved voice clips. Export runs in real time in a recent Chrome or Edge browser.

Browser speech synthesis can read a script during preview when a scene has no saved voice. **Browser speech synthesis is not captured in the exported video.** Record, import, or generate and save a voice clip to include speech in exports.

## Optional AI writing, backgrounds, and character voices

Set keys in the **server** environment (`.env` locally, or deployment secrets). Never use `NEXT_PUBLIC_` for these keys:

```dotenv
OPENROUTER_API_KEY=your_openrouter_key
POLLINATIONS_API_KEY=your_pollinations_key
ELEVENLABS_API_KEY=your_elevenlabs_key
```

- **OpenRouter:** uses `openrouter/free` for original storyboards and scene-motion suggestions. If it is unavailable or no key exists, the built-in story writer takes over. Free-model rate limits apply.
- **Pollinations:** can generate background-only scene images and Kokoro character voice clips. Its current image/audio catalog can require Pollen credits, even with an API key; check its current model pricing before generating. Generated pictures are backdrops; the app adds an independently moving character in front.
- **ElevenLabs:** optional lifelike, expressive character voices. The Voice tab lists the voices available to your account, generates scene clips with your chosen voice, and includes them in the export. A free plan may allow personal/non-commercial testing, but **commercial use/monetized YouTube videos require a plan with commercial rights**. Its monthly character and API limits apply.

Voice generation is optional. Your own recording/import works without provider keys or credits, subject to your rights to the audio. Do not clone or imitate someone else's voice without permission.

Arena is a model-comparison website, not a public video-generation API. This app draws and records animated cartoons locally in the browser; it does not claim to synthesize cinematic AI video for free.

## How to use the editor

1. Unlock your studio and open a project or create a new storyboard.
2. In **Motion**, set the character's action and mood, camera move, scene transition, length, background, character, and prop. Upload your own art, or optionally generate a backdrop.
3. In **Voice**, record or import a voice for a scene. Alternatively, configure an AI provider, choose a voice, and generate one or all scenes. Adjust music and voice levels. The voice player confirms what is saved.
4. In **Text**, refine the story title, captions, narration, background prompt, and caption style.
5. Use the **timeline** to scrub, drag scenes into a new order, duplicate, or undo edits. Save your changes.
6. Export a WebM and watch it. **Share** lets you review title, description, privacy, and the made-for-kids checkbox before uploading.

Keep narration short enough for each scene; the editor warns when a recorded/generated voice runs longer than a clip. Background music is synthesized by the app and does not require a stock-media license.

## Connect YouTube

1. Enable **YouTube Data API v3** in a Google Cloud project.
2. Configure the OAuth consent screen. For a testing app, add your own Google account as a test user.
3. Create an **OAuth client ID** of type **Web application**.
4. Add the exact authorized redirect URI: `https://YOUR_DOMAIN/api/youtube/callback` (for local development, `http://localhost:3000/api/youtube/callback`).
5. Set the credentials in the server environment:

```dotenv
GOOGLE_CLIENT_ID=your_client_id
GOOGLE_CLIENT_SECRET=your_client_secret
GOOGLE_REDIRECT_URI=https://YOUR_DOMAIN/api/youtube/callback
APP_ENCRYPTION_KEY=a_long_stable_random_secret
```

`GOOGLE_REDIRECT_URI` defaults to the current origin plus `/api/youtube/callback` if omitted. `APP_ENCRYPTION_KEY` encrypts stored refresh tokens; if omitted, the Google client secret is used. If you change either encryption key after connecting, reconnect YouTube.

6. Unlock your studio and select **Settings → Connect YouTube**.
7. In the project editor, review the finished video and publish settings, confirm it is made for kids, and click **Render & upload Short**.

Uploads are **private by default** and marked **made for kids**. Google's YouTube API quota and verification restrictions apply; unverified projects may be limited to private uploads. Nothing publishes unattended: you explicitly review and start every upload.

## Run locally

The app requires Node.js, PostgreSQL, and `DATABASE_URL` in `.env`.

```bash
npm install
npx drizzle-kit push
npm run dev
```

Create your owner PIN on the first visit. For public deployment, use HTTPS and set a strong owner passphrase before sharing the URL. The unclaimed first-run demo contains sample stories only; whoever completes the initial setup becomes the sole owner.
