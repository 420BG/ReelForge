import { isExhausted, looksLikeQuotaError, markCall, markFailure } from "@/lib/pipeline/usage";

/**
 * Server-only text model access for the agent. Uses the SAME providers, env names and
 * daily-quota tracking as ReelForge's script pipeline: Groq → Gemini → OpenRouter, then any
 * extra free tiers you add keys for (Cerebras, Mistral, SambaNova, Cloudflare Workers AI,
 * GitHub Models), Pollinations text, and finally Pollinations' key-less endpoint.
 * A provider that hits its daily quota is skipped until the next UTC day.
 */

export type LlmResult = { json: Record<string, unknown>; model: string };

export function extractJson(text: string): Record<string, unknown> | null {
  const fenced = text.replace(/```json|```/g, "");
  const start = fenced.indexOf("{");
  const end = fenced.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try { return JSON.parse(fenced.slice(start, end + 1)); } catch { return null; }
}

type Provider = { id: string; model: string; enabled: () => boolean; call: (system: string, user: string, maxTokens: number) => Promise<{ status: number; text: string; content?: string }> };

const timeout = () => AbortSignal.timeout(process.env.VERCEL ? 60_000 : 75_000);

async function chatCompletions(url: string, key: string, model: string, system: string, user: string, maxTokens: number, extra: Record<string, unknown> = {}, headers: Record<string, string> = {}) {
  const response = await fetch(url, {
    method: "POST",
    headers: { ...(key ? { Authorization: `Bearer ${key}` } : {}), "Content-Type": "application/json", ...headers },
    body: JSON.stringify({ model, temperature: 0.85, max_tokens: maxTokens, messages: [{ role: "system", content: system }, { role: "user", content: user }], ...extra }),
    signal: timeout(),
    cache: "no-store",
  });
  const text = await response.text();
  let content: string | undefined;
  try { content = JSON.parse(text)?.choices?.[0]?.message?.content; } catch { /* keep undefined */ }
  return { status: response.status, text, content };
}

const PROVIDERS: Provider[] = [
  {
    id: "groq", model: "llama-3.3-70b-versatile", enabled: () => Boolean(process.env.GROQ_API_KEY),
    call: (s, u, m) => chatCompletions("https://api.groq.com/openai/v1/chat/completions", process.env.GROQ_API_KEY!, "llama-3.3-70b-versatile", s, u, m, { response_format: { type: "json_object" } }),
  },
  {
    id: "gemini", model: "gemini-2.0-flash", enabled: () => Boolean(process.env.GEMINI_API_KEY),
    call: async (s, u, m) => {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: s }] }, contents: [{ parts: [{ text: u }] }], generationConfig: { temperature: 0.85, maxOutputTokens: m, responseMimeType: "application/json" } }),
        signal: timeout(),
        cache: "no-store",
      });
      const text = await response.text();
      let content: string | undefined;
      try { content = JSON.parse(text)?.candidates?.[0]?.content?.parts?.[0]?.text; } catch { /* keep undefined */ }
      return { status: response.status, text, content };
    },
  },
  {
    id: "openrouter", model: "meta-llama/llama-3.3-70b-instruct:free", enabled: () => Boolean(process.env.OPENROUTER_API_KEY),
    call: (s, u, m) => chatCompletions("https://openrouter.ai/api/v1/chat/completions", process.env.OPENROUTER_API_KEY!, "meta-llama/llama-3.3-70b-instruct:free", s, u, m, {}, { "HTTP-Referer": process.env.APP_URL ?? "http://localhost:3000", "X-Title": "ReelForge Agent" }),
  },
  // ---- extra free tiers (all optional; add the env var in Vercel to switch one on) ----
  {
    id: "cerebras", model: process.env.CEREBRAS_MODEL || "llama-3.3-70b", enabled: () => Boolean(process.env.CEREBRAS_API_KEY),
    call: (s, u, m) => chatCompletions("https://api.cerebras.ai/v1/chat/completions", process.env.CEREBRAS_API_KEY!, process.env.CEREBRAS_MODEL || "llama-3.3-70b", s, u, m, { response_format: { type: "json_object" } }),
  },
  {
    id: "mistral", model: process.env.MISTRAL_MODEL || "mistral-small-latest", enabled: () => Boolean(process.env.MISTRAL_API_KEY),
    call: (s, u, m) => chatCompletions("https://api.mistral.ai/v1/chat/completions", process.env.MISTRAL_API_KEY!, process.env.MISTRAL_MODEL || "mistral-small-latest", s, u, m, { response_format: { type: "json_object" } }),
  },
  {
    id: "sambanova", model: process.env.SAMBANOVA_MODEL || "Meta-Llama-3.3-70B-Instruct", enabled: () => Boolean(process.env.SAMBANOVA_API_KEY),
    call: (s, u, m) => chatCompletions("https://api.sambanova.ai/v1/chat/completions", process.env.SAMBANOVA_API_KEY!, process.env.SAMBANOVA_MODEL || "Meta-Llama-3.3-70B-Instruct", s, u, m),
  },
  {
    id: "cloudflare-ai", model: process.env.CLOUDFLARE_TEXT_MODEL || "@cf/meta/llama-3.3-70b-instruct-fp8-fast", enabled: () => cloudflareConfigured(),
    call: (s, u, m) => chatCompletions(`https://api.cloudflare.com/client/v4/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/ai/v1/chat/completions`, process.env.CLOUDFLARE_API_TOKEN!, process.env.CLOUDFLARE_TEXT_MODEL || "@cf/meta/llama-3.3-70b-instruct-fp8-fast", s, u, m),
  },
  {
    id: "github-models", model: process.env.GITHUB_MODELS_MODEL || "openai/gpt-4o-mini", enabled: () => Boolean(process.env.GITHUB_MODELS_TOKEN),
    call: (s, u, m) => chatCompletions("https://models.github.ai/inference/chat/completions", process.env.GITHUB_MODELS_TOKEN!, process.env.GITHUB_MODELS_MODEL || "openai/gpt-4o-mini", s, u, Math.min(m, 4000)),
  },
  {
    id: "pollinations-text", model: "openai", enabled: () => Boolean(process.env.POLLINATIONS_API_KEY),
    call: (s, u, m) => chatCompletions("https://gen.pollinations.ai/v1/chat/completions", process.env.POLLINATIONS_API_KEY!, "openai", s, u, m),
  },
  {
    // Key-less community endpoint: last resort, can be slow or rate-limited. Turn off with POLLINATIONS_KEYLESS_TEXT=off.
    id: "pollinations-free-text", model: "openai", enabled: () => process.env.POLLINATIONS_KEYLESS_TEXT !== "off",
    call: (s, u, m) => chatCompletions("https://text.pollinations.ai/openai", "", "openai", s, u, m),
  },
];

export function cloudflareConfigured() {
  return Boolean(process.env.CLOUDFLARE_ACCOUNT_ID && process.env.CLOUDFLARE_API_TOKEN);
}

/** True when at least one KEYED model is set up (the key-less fallback alone doesn't count for factual niches). */
export function textModelConfigured() {
  return PROVIDERS.some((provider) => provider.id !== "pollinations-free-text" && provider.enabled());
}

/** Any model at all, including the key-less fallback (fine for fiction; factual niches still need a keyed one). */
export function textModelAvailable() {
  return PROVIDERS.some((provider) => provider.enabled());
}

/** Which script models are switched on, for the Settings page (names only — never values). */
export function textModelStatus() {
  return PROVIDERS.map((provider) => ({ id: provider.id, model: provider.model, configured: provider.enabled() }));
}

/** Walks the provider chain (skipping unconfigured / exhausted ones). Throws if none answers with JSON. */
export async function completeJson(system: string, user: string, maxTokens = 3500): Promise<LlmResult> {
  const errors: string[] = [];
  for (const provider of PROVIDERS) {
    if (!provider.enabled()) continue;
    if (await isExhausted(provider.id)) { errors.push(`${provider.id}: daily quota used`); continue; }
    try {
      const result = await provider.call(system, user, maxTokens);
      if (result.status !== 200) {
        await markFailure(provider.id, looksLikeQuotaError(result.status, result.text));
        errors.push(`${provider.id}: HTTP ${result.status}`);
        continue;
      }
      const json = result.content ? extractJson(result.content) : null;
      if (!json) { await markFailure(provider.id); errors.push(`${provider.id}: invalid JSON`); continue; }
      await markCall(provider.id);
      return { json, model: `${provider.id}:${provider.model}` };
    } catch (error) {
      await markFailure(provider.id);
      errors.push(`${provider.id}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw new Error(`No story model answered (${errors.join("; ") || "none configured"})`);
}
