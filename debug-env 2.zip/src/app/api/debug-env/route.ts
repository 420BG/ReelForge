export const dynamic = "force-dynamic";

function mask(v: string | undefined) {
  if (v === undefined || v === "") return "MISSING";
  if (v.length < 12) return `SET (${v.length} chars)`;
  return v.slice(0, 20) + "...(" + v.length + " chars)..." + v.slice(-10);
}

const KEYS = [
  "DATABASE_URL",
  "SUPABASE_URL",
  "SUPABASE_SERVICE_ROLE_KEY",
  "SUPABASE_STORAGE_BUCKET",
  "APP_PASSWORD",
  "APP_URL",
  "CRON_SECRET",
  "PEXELS_API_KEY",
  "OPENROUTER_API_KEY",
  "GROQ_API_KEY",
  "GEMINI_API_KEY",
  "GOOGLE_CLIENT_ID",
  "GOOGLE_CLIENT_SECRET",
  "FFMPEG_PATH",
  "FFPROBE_PATH",
];

export async function GET() {
  const out: Record<string, string> = {};
  for (const k of KEYS) out[k] = mask(process.env[k]);
  out.NODE_ENV = process.env.NODE_ENV ?? "MISSING";
  out.VERCEL_ENV = process.env.VERCEL_ENV ?? "not on vercel";
  return Response.json(out, { headers: { "Content-Type": "application/json" } });
}
