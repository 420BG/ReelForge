-- Run once in Supabase → SQL Editor. Additive only: creates the table the /api/settings route (added 27 Sept) expects.
CREATE TABLE IF NOT EXISTS app_settings (
  id integer PRIMARY KEY DEFAULT 1,
  daily_goal integer NOT NULL DEFAULT 3,
  timezone text NOT NULL DEFAULT 'Asia/Kathmandu',
  updated_at timestamptz NOT NULL DEFAULT now()
);
